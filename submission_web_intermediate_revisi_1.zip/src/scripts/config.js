const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
};

export default CONFIG;

export const MAP_SERVICE_API_KEY = "DIdazM5CIqV3Ba1NNLld";
